#include <iostream>
#include <vector>
#include <windows.h>
#include <queue>
#include <unordered_map>
#include <string>
#include <iomanip>
#include <conio.h>


using namespace std;


// Node template 
template<class T>class Node {
public:
	T data;
	Node* next;

public:
	Node()
	{
		next = NULL;
	}

	Node(T d){
		data = d;
		next = NULL;
	}
	
};

// linked list template
template<class T>class Linkedlist {
	public:
	Node<T>* head;

public:

	Linkedlist() { head = NULL; }

	void deleteNode(int nodeOffset){
		Node<T>*temp1 = head;
		Node<T>*temp2 = NULL;
		int ListLen = 0;
	
		if (head == NULL) {
			cout << "List empty." << endl;
			return;
		}
		while (temp1 != NULL) {
			temp1 = temp1->next;
			ListLen++;
		}
		if (ListLen < nodeOffset) {
			cout << "Index out of range"<< endl;
			return;
		}
		temp1 = head;
	
		if (nodeOffset == 1) {
	
		
			head = head->next;
			delete temp1;
			return;
		}
	
		while (nodeOffset-- > 1) {
	
			
			temp2 = temp1;
			temp1 = temp1->next;
		}
	
		temp2->next = temp1->next;
	
	
		delete temp1;
	}
	void insertNode(T data)
	{
		Node<T>* newNode = new Node<T>(data);
	

		if (head == NULL) {
			head = newNode;
			return;
		}
		Node<T>* temp = head;
		while (temp->next != NULL) {
			temp = temp->next;
		}
		temp->next = newNode;
	}
	
	T Select(int index){
		if(index==1){
			return head->data;
		}
		Node<T>* temp = head;
		for(int i=1;i<index;i++){
			temp=temp->next;
		}
		return temp->data;
	}
	void printList(){
		Node<T>* temp = head;
	
		
		if (head == NULL) {
			cout << "List empty" << endl;
			return;
		}
	
		while (temp != NULL) {
			cout << temp->data << " ";
			temp = temp->next;
		}
	}
	
};



//To add food item in menu
class FoodItem {
	public:
    	string name;
    	double price;
    	int quantity;
	public:
		FoodItem(){
		}
    	FoodItem(string n, double p) : name(n), price(p){}
    	string getName() const { return name; }
    	double getPrice() const { return price; }

};

//taking order from customer(user)
class Order {
private:
    Linkedlist<FoodItem> items;
    double totalPrice;
    int order_no;
    
public:
    Order() : totalPrice(0) {
    	srand(time(0));
    	order_no=rand()%4000+1;
	}
	int getOrderNo(){
		return order_no;
	}

    void addItem(FoodItem item, int quantity) {
       items.insertNode(item);
       totalPrice+=item.getPrice()*quantity;
    }
    void removeItem(int number) {
    	FoodItem f=items.Select(number);
    	items.deleteNode(number);
    	
       	totalPrice-=f.getPrice()*f.quantity;
    }
    double getTotalPrice() const { return totalPrice; }
    
    
    void printOrder() const {
    	Node<FoodItem>* temp = items.head;
    	if(temp==NULL){
    		cout<<"Sorry! You haven't order anything yet";
    		return;
		}
		int i=1;
		system("cls");
		system("Color CF");
		cout<<"  \n\n                  ******     BILL     ******   "<<endl;
		cout<<"        ---------------   Your Order  ---------------     "<<endl;
		cout<<"|| Item Number "<<"||   Item Name       "<<"||   Quantity  "<<"   ||  "<<"Price"<<endl;
    	while(temp!=NULL){
    		string n=temp->data.name;
    		int y=n.size();
    		cout<<"|| "<<i<<"           ||  "<<temp->data.name<<setw(20-y)<<"|| "<<temp->data.quantity<<"              ||"<<temp->data.price<<endl;
    		temp=temp->next;
    		i++;
		}
    }
};


class Edge {
public:
    int to;
    int weight;

    Edge(int to, int weight) {
        this->to = to;
        this->weight = weight;
    }
};

//Using graph
class Graph {
public:
    int V;
    vector<vector<Edge>> adj;
    unordered_map<int, string> vertex_names;

    Graph(int V) {
        this->V = V;
        adj.resize(V);
    }

    
    void addEdge(int from, int to, int weight) {
        adj[from].push_back(Edge(to, weight));
    }
    
    void addVertexName(int vertex, string name) {
        vertex_names[vertex] = name;
    }
};

// Function to implement Dijkstra's algorithm
vector<int> dijkstra(Graph g, int start) {
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    vector<int> dist(g.V, INT_MAX);
    pq.push({ 0, start });
    dist[start] = 0;

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        for (auto e : g.adj[u]) {
            int v = e.to;
            int weight = e.weight;
            if (dist[v] > dist[u] + weight) {
                dist[v] = dist[u] + weight;
                pq.push({ dist[v], v });
            }
        }
    }
    return dist;
}

//Generating total amount with the delivery charges
class Bill{
	public:	
	Bill(int m,int n, int amount){
		Graph g(14);
		
	    // Add the names of vertices to the graph
	    g.addVertexName(1, "University road");
	    g.addVertexName(2, "Karsaz");
	    g.addVertexName(3, "Bahadurabad");
	    g.addVertexName(4, "Gulshan-E-Iqbal");
	    g.addVertexName(5, "North Nazimabad");
	    g.addVertexName(6, "Baloch Colony");
	    g.addVertexName(7, "Defense");
	    g.addVertexName(8, "Clifton");
	    g.addVertexName(9, "Metropole");
	    g.addVertexName(10, "Kemari");
	    g.addVertexName(11, "Saddar");
	    g.addVertexName(12, "Gulberg");
	    g.addVertexName(13, "Lyari Expressway");
	
	    // Add edges to the graph
	    g.addEdge(1, 2, 30);    g.addEdge(2, 1, 30);
	    g.addEdge(1, 3, 40);	 g.addEdge(3, 1, 40);
	    g.addEdge(1, 4, 30);    g.addEdge(4, 1, 30);
	    g.addEdge(1, 5, 40);    g.addEdge(5, 1, 40);
	    g.addEdge(2, 3, 20);    g.addEdge(3, 2, 20);
	    g.addEdge(3, 6, 90);    g.addEdge(6, 3, 90);
	    g.addEdge(3, 9, 70);    g.addEdge(9, 3, 70);
	    g.addEdge(4, 5, 30);    g.addEdge(5, 4, 30);
	    g.addEdge(4, 13, 12);  g.addEdge(13, 4, 12);
	    g.addEdge(6, 7, 80);    g.addEdge(7, 6, 80);
	    g.addEdge(7, 8, 70);    g.addEdge(8, 7, 70);
	    g.addEdge(8, 9, 50);    g.addEdge(9, 8, 50);
	    g.addEdge(8, 10, 30);   g.addEdge(10, 8, 30);
	    g.addEdge(9, 10, 40);   g.addEdge(10, 9, 40);
	    g.addEdge(9, 11, 30);   g.addEdge(11, 9, 30);
	    g.addEdge(10, 11, 60);  g.addEdge(11, 10, 60);
	    g.addEdge(11, 12, 30);  g.addEdge(12, 11, 30);
	    g.addEdge(12, 13, 50);  g.addEdge(13, 12, 50);
	
	    vector<int> cash = dijkstra(g, m);
	    system("Color CF");
	    int payment_option;
	    cout <<"\nTotal Amount of Food is: "<<amount<<endl;
        cout <<"\nThe Total Delivery Charges from "<< "our restaurant "<<" to "<< g.vertex_names[n] << " is: " << cash[n] << "Rs"<< endl;
        cout<<"\nDo you want to pay by cash or by credit?"<<endl;
        cout<<"For cash press 2 and for credit press 3:"<<endl;
        cin>>payment_option;
        if(payment_option==2){
        	cout<<"\nThe total amount with delivery charges to pay by cash is: "<<amount + cash[n]<<"Rs"<<endl;
			}
		if(payment_option==3)
			{
			cout<<"\nThe total amount with delivery charges to pay by credit is:"<<amount + cash[n]<<"Rs"<<endl;
		}
		Sleep(2000);
		system("cls");
		
	}
	
};


//Display to customer
class Customer {
public:
    string name;
    string phone;
    int cash;
    Order currentOrder;
    vector<FoodItem> menu;
public:
	Customer(){
		FoodItem f1("Burger",250);
		FoodItem f2("Steak",350);
		FoodItem f3("AlFredo Pasta",700);
		FoodItem f4("Cheese Burger",550);
		FoodItem f5("Normal Pizza",750);
		FoodItem f6("Animal fries",500);
		FoodItem f7("Pepsi",70);
		FoodItem f8("Brownie",300);
			
		vector<FoodItem> menu1;
		menu1.push_back(f1);
		menu1.push_back(f2);
		menu1.push_back(f3);
		menu1.push_back(f4);
		menu1.push_back(f5);
		menu1.push_back(f6);
		menu1.push_back(f7);
		menu1.push_back(f8);
		menu=menu1;
	}
    
    string getName() const { return name; }
    string getPhone() const { return phone; }
    Order& getCurrentOrder() { return currentOrder; }
    void printCustomerInfo() const {
	cout<< "Customer: "<< name <<endl;
	cout<< "Phone no: "<< phone <<endl; 
	}

//Displaying menu
    void display_menu(){
    	system("Color CF");
    	cout<<"\n         -------------------------------------------"<<endl;
    	cout<<"                      *******MENU*******"<<endl;
    	cout<<"         -------------------------------------------"<<endl;
    	for(int i = 0 ; i<menu.size();i++ ){
    		FoodItem f=menu[i];
    		cout<<i+1<<"   ||"<<menu[i].name<<setw(20-f.name.size())<<"|| "<<menu[i].price<<endl;
		}
	}
	
//Registering customer and taking order details
    void  order_Food(){
    	system("Color CF");
		cout<<"Enter your Name: ";
		cin>>name;
		cout<<"Enter your Phone Number: ";
		cin>>phone;
		cout<<"You are registered successfully!"<<endl;
		
    	display_menu();
    	
		cout<<"\n\n";
		cout<<"Enter the food item number you want to buy(1-8):"<<endl;
		int choice;
		cin>>choice;
		cout<<"Enter the quantity of chosen food item:"<<":"<<endl;
		int q;
		cin>>q;
		FoodItem f=menu[choice-1];
		f.quantity=q;
		currentOrder.addItem(f,q);
		ordering();
		cout<<"\nOrder placed successfully!"<<endl;
		currentOrder.printOrder();
		
		cout<<"\n\nIf you want to delete any item press: 1 (You can only delete one item at a time)";
		cout<<"\nElse press any other number key to continue:"<<endl;
		int x;
		cin>>x;
		if(x==1){
			cout<<"Enter the food item number from your order which you want to delete: "<<endl;
			int w;
			cin>>w;
			currentOrder.removeItem(w);
		}
		currentOrder.printOrder();
		
		int s;
		system("cls");
		system("Color CF");
		
//Displaying locations we are delivering to currently
		cout<<"\nCurrently we are only delivering to following locations:";
		cout<<"\n\n\n1)University Road\n2)Karsaz\n3)Bahadurabad\n4)Gulshan-E-Iqbal\n5)North Nazimabad\n";
		cout<<"6)Baloch Colony\n7)Defense\n8)Clifton\n9)Metropole\n10)Kemari\n11)Saddar\n12)Gulberg\n13)Lyari Expressway\n\n";
		cout<<"\nEnter the place from where you Ordering(1-13): ";
		cin>>s;
		Bill b(1,s,currentOrder.getTotalPrice());			
	}
	
	void ordering() {
		system("Color CF");
		cout<<"\nIf you want to order anything else enter number(1-8) else enter (-1):" <<endl;
		int choice ;
		cin>>choice;
		if(choice==-1){
			return;
		}
		cout<<"Enter the Quantity:"<<endl;
		int q;
		cin>>q;
		FoodItem f=menu[choice-1];
		f.quantity=q;
		currentOrder.addItem(f,q);
		//Recursive function
		ordering();
	}

};

//For the owner to access admin portal
class Admin{
	
	public:
	string userName="finalfour", password="4321";
	
	
	public:
		//Options for the admin
	int adminPortal(int *ch){
		system("Color CF");
		cout<<"\t\t\tAdmin Portal"<<endl;
		cout<<"\t\t\tPress<1> To add New Customer on Stream "<<endl;
		cout<<"\t\t\tPress<2> To finish serving"<<endl;
		cout<<"\t\t\tpress<3> to return"<<endl;
		cout<<"Enter your choice : "<<endl;
		int choice;
		cin>>choice;
		
	    if (choice==1){
	    	return 1;
	    	
		}	
		if (choice==2){
			return 2;
		}
		system("cls");
		*ch=-1;
		return -1;
		
	}
	//Admin logging in
    bool login(){
	    string username;
	    string pass;
	    system("Color CF");
		cout << "Login your account \n";
	    cout << "Enter username(no spaces):";
	    cin >> username;
	    cout << "Enter password:";
	    cin >> pass;
	    if(username==userName && password==pass){
	    	
	    	cout << "Login successful \n";
	    	return true;
	    	system("cls");
		}
	    cout << "Invalid Credentials \n";
    	return false;
    	
	}
};

//Main menu
//Shows options for the user
class RestaurantApp{
public:
	
   queue<Customer> c1;
   Admin a1;
	
public:
   void menu(){
   	    system("Color 1F");
   		cout<<"\n\n";
   		cout<<"\t\t\tWELCOME TO FINAL FOUR RESTAURANT \n\n\n"<<endl;
   		cout<<"\t\t\tORDER THE BEST FOOD IN THE TOWN\n\n";
   		cout<<"\t\t\tPress<1> If you are Admin"<<endl;
   		cout<<"\t\t\tPress<2> If you are User(order food)\n";
   		cout<<"\t\t\tPress<3> To check current Serving\n";
   		int choice;
   		cout<<"\t\t\tEnter your Choice : ";
   		cin>>choice;
   		system("cls");
   		if(choice==1){
			if(a1.login()){
				int check=1;
				while(check==1){
					
					int a=a1.adminPortal(&choice);
					if(a==1){
						addCustomerOnStream();
					
					}
					if(a==2){
						finishServing();
				
					}
					menu();	
				}
			}
		}
		if(choice==2){
			system("Color CF");
			Customer c2;
			c2.order_Food();
			c1.push(c2);
			menu();
		}
		if(choice==3){
			system("Color CF");
			cout<<"We are now serving ...."<<endl;
			Customer check=c1.front();
			check.printCustomerInfo();
			cout<<"Order_no is "<<check.currentOrder.getOrderNo();
			int s;
			cout<<"\n\nEnter any number to go to menu!"<<endl;
			cin>>s;
			system("cls");
			menu();
		}
   }
   //To remove the customer from queue and add next customer in queue for serving
   void finishServing(){
   	    system("Color CF");
   		if(!c1.empty()){
	   		Customer c=c1.front();
	   		cout<<"Customer : "<<c.name<<" is served"<<endl;
	   		c1.pop();
	   		if(!c1.empty()){
	  			c=c1.front();
	   			cout<<"Customer : "<<c.name<<" is now serving....."<<endl;
	   			Sleep(2000);
				system("cls");	   			
	   			return;
	   	
	   		}
	   		cout<<"Queue is now empty!"<<endl;
	   		Sleep(2000);
	   		system("cls");
	   		return;
   		}
   		cout<<"Queue is empty not Customer to serve!"<<endl;
   		Sleep(2000);
   	    system("cls");
   		return ;
   		
   	}
   	//Function that adds customer through admin portal
   void addCustomerOnStream(){
			Customer c2;
			c2.order_Food();
			c1.push(c2);
			
	}
	
};
int main(){
	//Customer already waiting in the queue
	Customer q1;
	q1.name="Ayesha";
	q1.phone="03323829191";
	Customer q2;
	q2.name="Yashfa";
	q2.phone="03367263434";
	queue<Customer> c1;
	c1.push(q1);
	c1.push(q2);
	RestaurantApp a;
	a.c1=c1;

	a.menu();
}
